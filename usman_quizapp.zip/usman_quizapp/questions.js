var questions = [{
    "question":"The use of computer work stations to send and receive messages is known as ?",
    "option1": "(a)	electronic funds transfer",
    "option2":"(b)	electronic message switching",
    "option3":"(c)	electronic mail",
    "option4":"(d)	electronic publishing",
    "answer":"3"
  
},{
    "question":"Protecting the data from unauthorized access is called",
    "option1": "(a)	data inaccessibility",
    "option2": "(b)	data encryption",
    "option3": "(c)	data security",
    "option4": "(d)	data validity",
    "answer": "3",
},{
    "question":"What is true about supercomputers",
    "option1": "(a)	they can fit on a single small chip",
    "option2": "(b)	they are found at thousands of places around the world",
    "option3": "(c)	they cost only few thousand rupee",
    "option4": "(d)	they can process billions of operations in a second",
    "answer": "4",
},{
    "question":"In a distributed computer system",
    "option1": "(a)	there are many computers and terminals",
    "option2": "(b)	the task is executed by a number of processors",
    "option3": "(c)	the task is distributed throughout the system",
    "option4": "(d)	All of the above.",
    "answer": "3",
},{
    "question":"The linking of computers with a communication system is called",
    "option1": "(a)	networking",
    "option2": "(b)	pairing",
    "option3": "(c)	interfacing",
    "option4": "(d)	assembling",
    "answer": "1",
},{
    "question":"Distributed data entry means that data can be",
    "option1": "(a)	entered at different locations where it originates",
    "option2": "(b)	sent to different locations from a central place",
    "option3": "(c)	accessed from different places know as distribution points",
    "option4": "(d)	distributed through a network",
    "answer": "1",
},{
    "question":". Software documentation refers to",
    "option1": "(a)	anything written about how the software is designed or functions",
    "option2": "(b)	the documents which, the user has to sign before using the software legally",
    "option3": "(c)	the compatibility of the software with IBM-PC",
    "option4": "(d)	None of the above.",
    "answer": "1",
},{
    "question":". If a home computer user wants access to national database networks he/she at least requires",
    "option1": "(a)	a microcomputer, a modem, a telephone line",
    "option2": "(b)	a microcomputer, a tele-printer, a telephone line",
    "option3": "(c)	a microcomputer, communications soft-ware, a telephone line",
    "option4": "(d)	a microcomputer, a modem, communications software, a telephone line",
    "answer": "4",
},{
    "question":"Which of the following functions of a computer is wrong?",
    "option1": "(a)	it obtains data from an input device",
    "option2": "(b)	it processes the data and delivers the final results to an output device",
    "option3": "(c)	it takes processing steps from the list of instructions called program",
    "option4": "(d)	It generates the program on its own.",
    "answer": "4",
},{
    "question":"The heart of a computer is",
    "option1": "(a)	CPU",
    "option2": "(b)	Memory",
    "option3": "(c)	I/O Unit",
    "option4": "(d)	Disks",
    "answer": "1",
},

]